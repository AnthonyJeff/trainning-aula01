<?php  

	$numero = rand(1, 12);
	//$numero = 1;

	switch($numero){

		case 1:
			echo "O mês é janeiro";
		break;

		case 2:
			echo "O mês é fevereiro";
		break;

		case 3:
			echo "O mês é marco";
		break;	

		case 4:
			echo "O mês é abril";
		break;	

		case 5:
			echo "O mês é maio";
		break;	

		default:
			echo "O mês é maior que o de maio";

	}



?>