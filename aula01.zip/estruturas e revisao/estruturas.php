<?php  
	
	# Idade randomica
	$idade = rand(10,90);

	/* Algorimo: 
		idade < 12 retorna criança
		idade < 18 retorna adolescente
		idade < 59 retorna aduto
		idade > 59 retorna idoso
	*/

	echo "Idade: $idade <br>";

	# Testando se a idade é maior do que 18 anos
	if($idade < 12 ){
		echo "Criança <br>";
	}else{
		if($idade < 18){
			echo "adolescente <br>";
		}else{
			if($idade < 59){
				echo "Adulto <br>";
			}else{
				echo "Idoso <br>";
			}
		}		
	}
	
	if($idade < 12){
		echo "Criança <br>";
	}elseif($idade < 18){
		echo "adolescente <br>";
	}elseif($idade < 18){
		echo "Adulto <br>";
	}else{
		echo "Idoso <br>";
	}



?>