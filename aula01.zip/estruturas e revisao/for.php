<?php  

	# Algoritmo conta de 0 até 10
	# para 1 até 10 mostra de 1 em 1 
	/*for($inicio = 0; $inicio < 11; $inicio++){
		echo "Contando $inicio <br>";
	}*/

	// Criando o campo ANO (começando em 2022 até 1900)

	# Criar uma tabela dinâmica
	# Tabela n linhas e m colunas
	$nLinhas = 25;
	$nColunas = 10;


?>

<table border='2'>
	<?php for($linhas = 1; $linhas <= $nLinhas; $linhas++): ?>
		<tr>
			<?php for($colunas = 1; $colunas <= $nColunas; $colunas++): ?>
				<td><?= $linhas." - ".$colunas;?></td>
			<?php endfor; ?>
		</tr>
	<?php endfor; ?>
</table>


<?php  
	
	# Algoritmo: crie um contador que vá de 0 a 10 e outro de 0 a 100;	
	for($a=0,$b=0; $a < 11; $a++, $b+=10){
		echo "A vale $a e o B vale $b <br>";
	}

?>