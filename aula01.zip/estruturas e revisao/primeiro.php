<?php 

	# É um comentário em uma linha
	// É um comentário em uma linha
	/* 
		Comentário em multiplas linhas
	*/

	# Vamos ver as informações do php instalado
	// phpinfo();	

	// Mostrando algo na tela
	echo "<h1> Meu primeiro code php </h1>";

	# Criando uma variável em PHP
	$nome = "Anthony Jefferson";
	$nome = "Flavio";
	
	echo "Bem vindo(a) ao curso de PHP ";
	echo $nome;
	echo " ! <br>";

	echo "Bem vindo (a) ao curso de PHP ".$nome." !<br>";
	echo "Bem vindo (a) ao curso de PHP $nome ! <br>";
	echo 'Bem vindo (a) ao curso de PHP '.$nome.' ! <br>';
	echo "Bem vindo (a) ao curso de PHP ", $nome,' ! <br>';

	
?>

