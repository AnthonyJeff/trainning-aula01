<?php  

	# Conceito de Variáveis
	$nome = "Anthony"; // String
	$email = "anthony@email.com"; // String
	$idade = 28; // Inteiro (numerico)
	$cpf = "041.456.789-90"; //String
	$saldoBancário = -574.89; // Float (Double)
	$usuarioAtivoNoCurso = true; // Boleano

	echo $nome."<br>";


?>