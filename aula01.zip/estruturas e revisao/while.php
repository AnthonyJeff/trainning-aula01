<?php  

	# Algoritmo: contador de 0 a 10

	$numero = 0;

	/*while($numero < 11){
		echo "Contando $numero <br>";
		$numero++;
	}*/

	for(;$numero<11;){
		echo "Contando $numero <br>";
		$numero++;
	}


	/*do {
		echo "Contando $numero <br>";
		$numero++;
	} while ( $numero < 11);*/


?>