<?php  

	# Recebendo os dados do formulário
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$senha = $_POST['senha'];
	$dtnasc = $_POST['dtnasc'];


	echo "Meu nome é: ".$nome." <br>";
	echo "Meu email é: ".$email." <br>";
	echo "Minha senha é: ".sha1($senha)." <br>";
	echo "Minha data de nascimento é: ".$dtnasc."<br>";

?>