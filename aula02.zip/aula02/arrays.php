<?php 


	# Frutas no formato de váriavel
	/*$fruta1 = "Manga";
	$fruta2 = "Caju";
	$fruta3 = "Siriguela";
	$fruta4 = "Cajá";
	$fruta5 = "Murici";
	*/
	// [0 1] sintaxe
	
	# Arrays 
	$frutas = array(0=>"Manga", 15=>"Caju", 2=>"Siriguela",3=>"Cajá", 4=>"Murici",5=>"Acerola",6=>"Goiaba");

	# Count -> conta o numero de elementos de um array
	$aux = count($frutas);

	# Imprimindo o array
	//echo $frutas[0]."<br>";
	//echo $frutas[1]."<br>";

	# Automatização para imprimir os valores
	/*for($w=0;$w<$aux;$w++){
		echo $frutas[$w]."<br>";
	}*/


	$pizza = [ "Mussarela"=>"Pedaço1", "4 Queijos"=>"Pedaço2", "Pedaço3", 1=>"Pedaço4", "Pedaço5", 2=>"Pedaço6" ];

	# Aplicando o foreach
	foreach($pizza as $chave=>$pedacos){
		echo $chave." - ".$pedacos."<br>";
	}

?>