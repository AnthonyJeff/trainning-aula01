<?php  
	
	# Guardar o id de quem eu quero excluir
	$id = $_GET['id'];
	
	# Ler o arquivo que contem os cadastros
	$cadastros = file("cadastros.txt");

	# Excluir quem eu quero do array (linhas do arquivo)
	unset($cadastros[$id]);

	# Excluir o arquivo
	unlink("cadastros.txt");

	# Transformando o array em string
	$string = implode("", $cadastros); // arquivo em txt
	
	# Criando o arquivo de texto
	$arquivo = fopen("cadastros.txt", "a+"); 

	# Escrevendo no arquivo
	fwrite($arquivo, $string);

	# Fechar o arquivo
	fclose($arquivo);
	
	# Redirecionamento
	header("location: listagem.php");




?>