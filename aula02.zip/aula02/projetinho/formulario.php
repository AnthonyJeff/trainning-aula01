<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
	<title> Iniciando com HTML </title>
</head>
<body>

	<nav class="navbar navbar-expand-lg bg-light">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="#"> TXT POWER </a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" id="navbarNav">
		      <ul class="navbar-nav">
		        <li class="nav-item">
		          <a class="nav-link active" aria-current="page" href="formulario.php">Cadastrar</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="listagem.php">Listar</a>
		        </li>
		        
		      </ul>
		    </div>
		  </div>
	</nav>

	<div class="container">
		<div class="row">
			
			<div class="col-6 offset-md-3 mt-5">

				<h1> Cadastro de Usuário </h1>
				<hr>
				<form action="recebe.php" method="POST">
					<div class="row">
						<div class="col-6">
							<label> Nome Completo: </label><br>
							<input type="text" class="form-control" name="nome" placeholder="Nome"><br>
						
							<label> Email: </label><br>
							<input type="email" class="form-control" name="email" placeholder="Email"><br>

							<label> Sexo: </label><br>
							<select name="sexo" class="form-control">
								<option> Masculino </option>
								<option> Feminino </option>
							</select><br>

							<label> Estado: </label><br>
							<input type="text" class="form-control" name="estado" placeholder="Estado"><br>
						</div>

						<div class="col-6">
							<label> Senha: </label><br>
							<input type="password" class="form-control" name="senha" placeholder="Senha"><br>
						
							<label> Data de Nascimento: </label><br>
							<input type="date" class="form-control" name="dtnasc" placeholder="Data de Nascimento"><br>

							<label> RG: </label><br>
							<input type="text" class="form-control" name="rg" placeholder="RG"><br>

							<label> Municipio: </label><br>
							<input type="text" class="form-control" name="municipio" placeholder="RG"><br>
						</div>

						<div class="col-12 text-end">
							<button class="btn btn-primary"> Enviar os Dados</button>
						</div>
					</div>
				</form>


			</div>
			<div class="col-3"></div>
		</div>

	</div>


</body>
</html>