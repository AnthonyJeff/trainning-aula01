<?php 
	
	# Ler o arquivo que contem os cadastros
	$cadastros = file("cadastros.txt");
?>

<!DOCTYPE html>
<html>
<head>
	<title> Listagem dos Cadastros </title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg bg-light">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="#"> TXT POWER </a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" id="navbarNav">
		      <ul class="navbar-nav">
		        <li class="nav-item">
		          <a class="nav-link active" aria-current="page" href="formulario.php">Cadastrar</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="listagem.php">Listar</a>
		        </li>
		        
		      </ul>
		    </div>
		  </div>
	</nav>
	<div class="container">


		<div class="row">
			<hr>
			<h3 class="text-center"> Lista de Cadastrados pelo TXT </h3>
			<hr>
			<div class="col-md-12">
				<table class="table table-striped">
				  <thead>
				  	<th> Nome </th>
				  	<th> Email</th>
				  	<th> Sexo </th>
				  	<th> Estado </th>
				  	<th> Senha </th>
				  	<th> Dt Nasc. </th>
				  	<th> RG </th>
				  	<th> Cidade </th>
				  	<th> Ações </th>
				  </thead>

				  <tbody>
				  	<?php //$contador = 0; ?>
				  	<?php foreach ($cadastros as $linha=>$cadastro): ?>
				  		<?php //$contador++; ?>
				  		<?php $cadastro = explode(" - ", $cadastro); ?>
				  		<tr>
					  		<?php foreach($cadastro as $dado): ?>
					  			<td><?=$dado;?></td>
					  		<?php endforeach; ?>

					  		<td>
					  			<button class="btn btn-warning"> 
					  				<span class="iconify" data-icon="bi:pencil-fill"></span> 
					  			</button>

					  			<a href="excluir.php?id=<?=$linha;?>" class="btn btn-danger"> 
					  				<span class="iconify" data-icon="bi:trash-fill"></span> 
					  			</a>

					  		</td>

				  		</tr>
				  		<?php //if($contador == $_GET['limit']){ break; } ?>
				  	<?php endforeach; ?>
				  </tbody>


				</table>
			</div>
		</div>
	</div>

	<script src="https://code.iconify.design/3/3.0.0/iconify.min.js"></script>

</body>
</html>