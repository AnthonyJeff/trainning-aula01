<?php  

	# Recebendo os dados do formulário e transformar o array em string
	$string = implode(" - ", $_POST); // arquivo em txt
	//$string = implode(";", $_POST); // arquivo para csv
	
	# Criando o arquivo de texto
	$arquivo = fopen("cadastros.txt", "a+"); 
	
	# Criando o arquivo de csv
	//$arquivo = fopen("cadastros.csv", "a+"); 

	# Escrevendo no arquivo
	fwrite($arquivo, $string. "\n");

	# Fechar o arquivo
	fclose($arquivo);
	
	# Redirecionamento
	header("location: listagem.php");

?>