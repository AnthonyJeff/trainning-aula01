<?php  
	
	# Algoritmo:  criar um arquivo com o php 
	/*
	# Criando o arquivo
	$arquivo = fopen("virus.exe", "a+"); 

	# Escrevendo no arquivo
	fwrite($arquivo, $array. "\n");

	# Fechar o arquivo
	fclose($arquivo);
	*/

	$frutas = ['oiti', 'manga', 'murici'];

	# Transformar um array em uma string
	$string = implode(" / ", $frutas);
	echo "STRING: " .$string ."<hr>";

	# Transformando uma string em array
	$array = explode(" / ", $string);
	print_r($array);
	echo "<hr>";

	# Eliminando uma posição do array
	unset($frutas[1]);

	print_r($frutas);

?>