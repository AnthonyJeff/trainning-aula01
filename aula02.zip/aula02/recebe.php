<?php  

	# Recebendo os dados do formulário
	$cadastro = $_POST;

	foreach ($cadastro as $chave => $valor) {
		echo "$chave -> $valor <br>";
	}


?>