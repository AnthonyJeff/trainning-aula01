<?php  

	include_once 'conexao.php';
	include_once 'gerenciador.php';

	# Recebendo os dados do Formulario
	$dados = $_POST;

	unset($dados['tabela'], $dados['filtro']);

	$filtro = explode("-", $_POST['filtro']);

	# Inserindo os dados no banco de dados:
	$resultado = atualizar($_POST['tabela'], $dados,[ $filtro[0]=>$filtro[1] ]);
	
	$page = $_POST['tabela'].".php";
	
	if($resultado){
		header("location: $page");
	}else{
		header("location: $page?erro=erro");
	}
?>

