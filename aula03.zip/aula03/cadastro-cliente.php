<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
	<title> Iniciando com HTML </title>
</head>
<body>
	<?php include_once 'layout/menu.php'; ?>
	<div class="container">
		<div class="row">
			
			<div class="col-6 offset-md-3 mt-5">

				<h1> Cadastro de Usuário </h1>
				<hr>
				<form action="insere.php" method="POST">
					<div class="row">
						<div class="col-6">
							<label> Nome Completo: </label><br>
							<input type="text" class="form-control" name="nome" placeholder="Nome"><br>
						
							<label> Email: </label><br>
							<input type="email" class="form-control" name="email" placeholder="Email"><br>							

							<label> CPF: </label><br>
							<input type="text" class="form-control" name="cpf" placeholder="Estado"><br>
						</div>

						<div class="col-6">
							<label> Endereço: </label><br>
							<input type="text" class="form-control" name="endereco" placeholder="Senha"><br>
						
							<label> Contato: </label><br>
							<input type="text" class="form-control" name="contato" placeholder="RG"><br>

							<input type="hidden" name="tabela" value="clientes">
						</div>

						<div class="col-12 text-end">
							<button class="btn btn-primary"> Enviar os Dados</button>
						</div>
					</div>
				</form>


			</div>
			<div class="col-3"></div>
		</div>

	</div>


</body>
</html>