<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
	<title> Iniciando com HTML </title>
</head>
<body>
	<?php include_once 'layout/menu.php'; ?>
	<div class="container">
		<div class="row">
			
			<div class="col-6 offset-md-3 mt-5">

				<h1> Cadastro de Usuário </h1>
				<hr>
				<form action="insere.php" method="POST">
					<div class="row">
						<div class="col-6">
							<label> Nome Produto: </label><br>
							<input type="text" class="form-control" name="produto_nome" placeholder="Nome"><br>
						
							<label> Cod do produto: </label><br>
							<input type="text" class="form-control" name="produto_codigo" placeholder="Email" value="<?=rand(1111111111111,999999999999);?>"><br>

							<label> Cod do produto: </label><br>
							<input type="number" class="form-control" name="produto_estoque" placeholder="Estoque"><br>
							
							<input type="hidden" name="tabela" value="produtos">	
						</div>						

						<div class="col-12 text-end">
							<button class="btn btn-primary"> Enviar os Dados</button>
						</div>
					</div>
				</form>


			</div>
			<div class="col-3"></div>
		</div>

	</div>


</body>
</html>