<?php  

	ini_set("display_errors", true );

	# dados da conexão com o banco de dados
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$banco = "loja";

	# criar uma conexão com o banco de dados;
	$conn = mysqli_connect($servidor, $usuario, $senha, $banco) or die("Erro de conexão!!! Verifique ".mysqli_connect_error());

	//var_dump($conn);

?>