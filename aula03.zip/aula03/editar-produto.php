<?php  
	
	include_once 'conexao.php';
	include_once 'gerenciador.php';

	$produto = buscar("produtos", null, ['id_produto'=>$_GET['id']], " LIMIT 1")[0];

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
	<title> Iniciando com HTML </title>
</head>
<body>
	<?php include_once 'layout/menu.php'; ?>
	<div class="container">
		<div class="row">
			
			<div class="col-6 offset-md-3 mt-5">

				<h1> Edição de Produto </h1>
				<hr>
				<form action="atualizar.php" method="POST">
					<div class="row">
						<div class="col-6">
							<label> Nome Produto: </label><br>
							<input type="text" class="form-control" value="<?=$produto['produto_nome'];?>" name="produto_nome" placeholder="Nome"><br>
						
							<label> Cod do produto: </label><br>
							<input type="text" class="form-control" value="<?=$produto['produto_codigo'];?>" name="produto_codigo" placeholder="Email" value="<?=rand(1111111111111,999999999999);?>"><br>

							<label> Estoque do produto: </label><br>
							<input type="number" class="form-control" value="<?=$produto['produto_estoque'];?>" name="produto_estoque" placeholder="Estoque"><br>
							
							<input type="hidden" name="id_produto" value="<?=$produto['id_produto'];?>">	
							<input type="hidden" name="filtro" value="id_produto-<?=$produto['id_produto'];?>">	
							<input type="hidden" name="tabela" value="produtos">	
						</div>						

						<div class="col-12 text-end">
							<button class="btn btn-primary"> Enviar os Dados</button>
						</div>
					</div>
				</form>


			</div>
			<div class="col-3"></div>
		</div>

	</div>


</body>
</html>