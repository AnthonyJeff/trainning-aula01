<?php  
	
	# Funcão Insert
	// INSERT INTO `clientes` (`nome`, `email`, `cpf`, `endereco`, `contato`) VALUES ('$_POST['nome']', 'joana@email.com','123.456.456-41','Rua Bem Alí, 226', '85 999544261');
	function inserir($tabela, $array){

		$query = "INSERT INTO `$tabela` ";

		$campos = "";
		foreach ($array as $key => $value) {
			$campos .= "`$key`, ";
		}

		$valores = "";
		foreach ($array as $key => $value) {
			$valores .= "'$value', ";
		}

		# Removendo a ultima virgula dos campos
		$campos = substr($campos, 0, -2);
		$valores = substr($valores, 0, -2);

		$query .= "($campos) VALUES ($valores)";


		# Resultado...
		//echo $query;
		global $conn;
		$resultado = mysqli_query($conn, $query);

		if($resultado == true){
			return true;
		}else{
			return false;
		}

	}

	# função select
	# SELECT * FROM `clientes` WHERE `id` = 3 ORDER BY nome LIMIT 10
	function buscar($tabela, $campos=null, $filtros, $extra){

		$query = "SELECT ";

		# Campos
		if($campos != null){
			foreach ($campos as $value) {
				$query .= "`$value`, ";
			}
			# Limpando a ultima virgula
			$query = substr($query, 0, -2);
		}else{
			$query .= "* ";
		}

		$query .= " FROM `$tabela` ";


		if($filtros != null){
			$query .= " WHERE "; 
			foreach ($filtros as $chave => $valor) {
				$query .= "`$chave` = '$valor' AND ";
			}
			
			$query = substr($query, 0, -4);
		}

		if($extra != null){
			$query .= $extra;
		}

		# Testes
		//echo $query;

		global $conn;
		
		$resultado = mysqli_query($conn, $query) or die(mysqli_error($conn));

		$data;
		while($linha = mysqli_fetch_assoc($resultado)){
			$data[] = $linha;
		}
		
		return $data;
	}

	# função select
	# UPDATE `clientes` SET `contato` = '11 254515415', `nome`= 'Mariana da Silva' WHERE `id` = '6';
	function atualizar($tabela, $dados, $filtros){

		$query = "UPDATE `$tabela` SET ";

		# Campos		
		foreach ($dados as $campo=>$novoValor) {
			$query .= "`$campo` = '$novoValor', ";
		}
		# Limpando a ultima virgula
		$query = substr($query, 0, -2);
				
		//if($filtros != null){
			$query .= " WHERE "; 
			foreach ($filtros as $chave => $valor) {
				$query .= "`$chave` = '$valor' AND ";
			}
			
			$query = substr($query, 0, -4);
		//}

		echo $query;

		global $conn;
		$resultado = mysqli_query($conn, $query);

		if($resultado == true){
			return true;
		}else{
			return false;
		}
	}

	function excluir($tabela, $filtros){

		$query = "DELETE FROM `$tabela` ";
				
		//if($filtros != null){
			$query .= " WHERE "; 
			foreach ($filtros as $chave => $valor) {
				$query .= "`$chave` = '$valor' AND ";
			}
			
			$query = substr($query, 0, -4);
		//}

		echo $query;

		
		global $conn;
		$resultado = mysqli_query($conn, $query);

		if($resultado == true){
			return true;
		}else{
			return false;
		}
		
	}

?>