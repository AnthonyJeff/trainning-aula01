<?php  

	include_once 'conexao.php';
	include_once 'gerenciador.php';

	# Recebendo os dados do Formulario
	$dados = $_POST;
	unset($dados['tabela']);

	# Inserindo os dados no banco de dados:
	$resultado = inserir($_POST['tabela'], $dados);

	
	$page = $_POST['tabela'].".php";
	
	if($resultado){
		header("location: $page");
	}else{
		header("location: $page?erro=erro");
	}
?>

