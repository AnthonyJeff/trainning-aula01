<?php  
	
	include_once 'conexao.php';
	include_once 'gerenciador.php';

	$produtos = buscar("produtos", null, null, " ORDER BY produto_nome");

	//var_dump($produtos);

?>

<!DOCTYPE html>
<html>
<head>
	<title> Listagem dos Produtos </title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
</head>
<body>
	<?php include_once 'layout/menu.php'; ?>
	<div class="container">

		<div class="row">
			<hr>
			<h3 class="text-center"> Lista de Clientes Cadastrados </h3>
			<hr>
			<div class="col-md-12">
				<table class="table table-striped">
				  <thead>
				  	<th> Nome Prod. </th>
				  	<th> Codigo Prod</th>
				  	<th> Estoque </th>				  	
				  	<th> Cadastro Em: </th>
				  	<th> Ações </th>
				  </thead>
				  <tbody>
				  	<?php foreach($produtos as $produto): ?>
				  		<tr>
				  			<td><?=$produto['produto_nome'];?></td>
				  			<td><?=$produto['produto_codigo'];?></td>
				  			<td><?=$produto['produto_estoque'];?></td>				  			
				  			<td><?=$produto['cadastradoEm'];?></td>
				  			<td>
				  				
				  				<a class="btn btn-warning" href="editar-produto.php?id=<?=$produto['id_produto'];?>"> 
					  				<span class="iconify" data-icon="bi:pencil-fill"></span> 
					  			</a>

				  				<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#excluir-produto-<?=$produto['id_produto'];?>">
								  <span class="iconify" data-icon="bi:trash-fill"></span>
								</button>


								<!-- Modal -->
								<form action="excluir.php" method="POST">
									<div class="modal fade" id="excluir-produto-<?=$produto['id_produto'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
									  <div class="modal-dialog">
									    <div class="modal-content">
									      <div class="modal-header">
									        <h1 class="modal-title fs-5" id="exampleModalLabel"> Excluir Produto</h1>
									        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									      </div>
									      <div class="modal-body">
									        <h3> Tem certeza que deseja excluir o produto <strong><?=$produto['produto_nome'];?></strong> ?! </h3>
									        <input type="hidden" name="id_produto" value="<?=$produto['id_produto'];?>">
									        <input type="hidden" name="tabela" value="produtos">
									      </div>
									      <div class="modal-footer">
									        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Não, fechar!</button>
									        <button type="submit" class="btn btn-success">Sim, certeza! </button>
									      </div>
									    </div>
									  </div>
									</div>
								</form>
				  			</td>
				  		</tr>
				  	<?php endforeach; ?>
				  	
				  </tbody>
				</table>
			</div>
		</div>
	</div>

	

	


	<script src="https://code.iconify.design/3/3.0.0/iconify.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>
</html>