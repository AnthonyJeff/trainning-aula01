-- Listagem dos bancos de dados que estão na sua instancia
SHOW DATABASES;

-- Criando um banco de dados
CREATE DATABASE `loja`;

-- Escolhendo o banco de dados para manipulação
USE `loja`;

-- 4 operações do banco de dados (C.R.U.D) Create / Read / Update / Delete

-- CRIANDO UMA TABELA de CLIENTES [ nome, email, cpf, endereço, contato ]
CREATE TABLE `clientes`(
	`id` INT(9) AUTO_INCREMENT PRIMARY KEY, 
	`nome` VARCHAR(50), 		
	`email` VARCHAR(50), 		
	`cpf` VARCHAR(20) UNIQUE KEY,
	`endereco` VARCHAR(40),
	`contato` VARCHAR(15),
	`cadastradoEm` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `produtos`(
	`id_produto` INT(9) AUTO_INCREMENT PRIMARY KEY, 
	`produto_nome` VARCHAR(20), 		
	`produto_codigo` VARCHAR(12) UNIQUE KEY,		
	`produto_estoque` INT(4),
	`cadastradoEm` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


--  MOSTRANDO AS TABELAS CRIADAS NO BANCO
SHOW TABLES;

-- ESTRUTURA DA TABELA
DESCRIBE `clientes`;

-- Populando com registros a tabela de clientes
INSERT INTO `clientes` (`nome`, `email`, `cpf`, `endereco`, `contato`)
VALUES 
('Joana das Quantas', 'joana@email.com','123.456.456-41','Rua Bem Alí, 226', '85 999544261'),
('João das Quantas', 'joao@email.com','123.456.456-42','Rua Bem Alí, 227', '85 999544261'),
('Mariana das Quantas', 'mariana@email.com','123.456.456-43','Rua Bem Alí, 228', '85 999544261'),
('Francisca das Quantas', 'fca@email.com','123.456.456-44','Rua Bem Alí, 229', '85 999544261'),
('Pedro das Quantas', 'pedro@email.com','123.456.456-45','Rua Bem Alí, 230', '85 999544261');



-- Mostrar os registros na tabela (* -> indica tudo da tabela)
SELECT * FROM `clientes`; -- Deem uma olhada no final da apostila

--  Select com condicional
SELECT * FROM `clientes` WHERE `id` > 5
SELECT * FROM `clientes` WHERE `id` = 2
SELECT * FROM `clientes` WHERE `id` = 3 OR `email` = 'mariana@email.com'


-- Atulizando um registro na Tabela;
UPDATE `clientes` SET `contato` = '11 254515415', `nome`= 'Mariana da Silva' 
WHERE `id` = '6';

-- Exclusão de um registro 
DROP DATABASE `BANCO`;
DROP TABLE `TABLE`;

DELETE FROM `clientes` WHERE `id` = 9;