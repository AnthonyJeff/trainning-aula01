<?php  
	
	/*
	# Incluindo um arquivo
	include_once 'conexao.php';

	# Inserir alguem no banco de dados
	$query = "INSERT INTO `clientes` (`nome`, `email`, `cpf`, `endereco`, `contato`) VALUES ('Joana das Quantas', 'joana@email.com','123.456.456-41','Rua Bem Alí, 226', '85 999544261');";

	# Enviar a query para o banco de dados
	$resultado = mysqli_query($conn, $query) or die(mysqli_error());

	var_dump($resultado);
	*/

	function somaDoisMaisDois(){
		echo 2+2;
	}

	function soma($a, $b){
		echo $a + $b;
	}

	function potencia($base, $exp){
		return pow($base, $exp);
	}


	$x = 55;

	function mostraX(){
		global $x;
		echo $x;
	}

	mostraX();

	//somaDoisMaisDois();
	//$a = 7; $b = 10;
	//soma($a, $b);
	//soma(100, 34787);

	//$resultado = potencia(10, 10);

	//echo $resultado/10;

?>