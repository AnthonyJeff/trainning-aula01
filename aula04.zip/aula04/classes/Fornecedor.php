<?php  

	class Fornecedor{

		private $nome;
		private $razao;
		private $cnpj;

		# Método construtor da classe
		public function __construct($nome, $razao, $cnpj){
			$this->nome = $nome;
			$this->razao = $razao;
			$this->cnpj = $cnpj;
		}

		public function getNome(){
			return $this->nome;
		}

		public function getRazao(){
			return $this->razao;
		}

		public function getCnpj(){
			return $this->cnpj;
		}


	}



?>