<?php  
	
	class Produto {

		private $descricao;
		private $estoque;
		private $preco;

		# Metódos acessores
		public function setDescricao($descricao){
			$this->descricao = $descricao;
		}

		public function getDescricao(){
			return $this->descricao;
		}


	}
?>