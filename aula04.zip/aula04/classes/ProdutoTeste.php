<?php  

	class ProdutoTeste{

		public $descricao;
		public $estoque;
		public $preco;

		# Metodos da classe
		public function entradaEstoque($qtd){
			# testando se a quantidade recibida é um numero e maior ou igual a 0
			if(is_numeric($qtd) and $qtd >= 0){
				$this->estoque += $qtd;
			}
		}

		public function saidaEstoque($qtd){
			# testando se a quantidade recibida é um numero e maior ou igual a 0
			if(is_numeric($qtd) and $qtd >= 0){
				$this->estoque -= $qtd;
			}
		}

		public function alterarPreco($porcento){
			if(is_numeric($porcento) and $porcento >= 0){
				$this->preco *= (1+($porcento/100));
			}
		}



	}


?>