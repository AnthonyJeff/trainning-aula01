<?php  

	// Criando a primeira classe em PHP
	class Usuario{
		
		# Atributos do Usuário
		public $nome;
		public $email;
		public $cpf;
		public $dtNasc;		


		# Método para imprimir os dados do usuário
		public function mostraDados(){
			echo $this->nome."<br>";
			echo $this->email."<br>";
			echo $this->cpf."<br>";
			echo $this->dtNasc."<br>";
		}

	}
	

?>