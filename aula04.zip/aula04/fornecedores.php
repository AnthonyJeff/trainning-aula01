<?php  

	include_once 'classes/Fornecedor.php';

	$magalu = new Fornecedor("Magalu", "Magazine Luiza S.A", "02156154221000130");

	echo "Fornecedor: ".$magalu->getNome()."<br>";
	echo "Razão Social: ".$magalu->getRazao()."<br>";
	echo "CNPJ: ".$magalu->getCnpj()."<br>";




?>


