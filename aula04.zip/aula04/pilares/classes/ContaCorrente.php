<?php  

	class ContaCorrente extends Conta{

		public $limite;

		public function __construct($agencia, $conta, $saldo, $limite){
			parent::__construct($agencia, $conta, $saldo); //utilizando o construtor PAI
			$this->limite = $limite;
		}	

		public function retirar($quantia){
			if($this->saldo + $this->limite >= $quantia){
				$this->saldo -= $quantia; // Retirada Permitida
			}else{
				return false; // Nao tem saldo suficiente
			}

			return true; // Retirada permitida (tudo ok)
		}	

		public function mostra(){
			echo "30";
		}
	}
	


?>