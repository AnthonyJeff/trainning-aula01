<?php  

	class ContaPoupanca extends Conta {

		public function retirar($quantia){
			if($this->saldo >= $quantia){
				$this->saldo -= $quantia;
			}else{
				return false; // Nao tem saldo suficiente
			}

			return true; // Retirada permitida (tudo ok)
		}

		public function mostra(){
			echo "20";
		}
	}


?>