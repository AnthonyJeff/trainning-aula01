<?php  

	include_once 'classes/Conta.php';
	include_once 'classes/ContaPoupanca.php';
	include_once 'classes/ContaCorrente.php';

	//$contas[] = new ContaCorrente(6677, "CC: 1234-56", 100, 500);
	//$contas[] = new ContaPoupanca(6678, "PP: 1234-57", 100);


	$poupanca = new ContaPoupanca(6678, "PP: 1234-57", 100);
	$corrente = new ContaCorrente(6677, "CC: 1234-56", 100, 500);
	$conta = new Conta(6679, "CC: 1234-59", 0);

	print_r($poupanca);
	echo "<br>";
	print_r($corrente);
	echo "<br>";
	print_r($conta);


?>