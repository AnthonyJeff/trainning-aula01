<?php 
		
	include_once 'classes/Conta.php';
	include_once 'classes/ContaPoupanca.php';
	include_once 'classes/ContaCorrente.php';

	# Crie os objetos
	$contas = array();

	$contas[] = new ContaCorrente(6677, "CC: 1234-56", 100, 500);
	$contas[] = new ContaPoupanca(6678, "PP: 1234-57", 100);

	foreach($contas as $key=>$conta){
		echo "Conta: ".$conta->getInfo()."<br>";
		echo "&nbsp;&nbsp;&nbsp; Saldo Atual: ".$conta->getSaldo()."<br>";
		$conta->depositar(200);
		echo "&nbsp;&nbsp;&nbsp; Deposito de 200 <br>";
		echo "&nbsp;&nbsp;&nbsp; Saldo Atual: ".$conta->getSaldo()."<br>";

		# Retirada de saldo
		if($conta->retirar(700)){
			echo "&nbsp;&nbsp;&nbsp; Retirada de 700!!! <br>";
		}else{
			echo "&nbsp;&nbsp;&nbsp; Retirada de 700 não permitida (Saldo Insulficiente) !!! <br>";
		}
		echo "&nbsp;&nbsp;&nbsp; Saldo Atual: ".$conta->getSaldo()."<br>";
	}	


?>