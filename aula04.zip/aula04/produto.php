<?php  

	# Incluindo o arquivo da classe
	include_once 'classes/Produto.php';
	
	$p1 = new Produto();
	$p1->setDescricao("Café Kimimo");

	echo $p1->getDescricao();
	//print_r($p1);

?>