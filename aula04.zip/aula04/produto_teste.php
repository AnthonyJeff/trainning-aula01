<?php  

	# Incluindo a classe Produto
	include_once 'ProdutoTeste.php';

	$p1 = new ProdutoTeste();
		$p1->descricao = "Arroz";
		$p1->estoque = 100;
		$p1->preco = 5.99;

	echo "O produto ".$p1->descricao." tem ".$p1->estoque." de estoque. [ ".date('d/m/Y H:i:s')." ] <br>";	
	$p1->saidaEstoque(10);
	echo "O produto ".$p1->descricao." tem ".$p1->estoque." de estoque. [ ".date('d/m/Y H:i:s')." ] <br>";
	$p1->saidaEstoque(57);
	echo "O produto ".$p1->descricao." tem ".$p1->estoque." de estoque. [ ".date('d/m/Y H:i:s')." ] <br>";
	$p1->entradaEstoque(133);
	echo "O produto ".$p1->descricao." tem ".$p1->estoque." de estoque. [ ".date('d/m/Y H:i:s')." ] <br>";

	echo "<hr>";
	echo "O produto ".$p1->descricao." custa R$ ".$p1->preco." reais. [ ".date('d/m/Y H:i:s')." ] <br>";	
	$p1->alterarPreco(15);
	echo "O produto ".$p1->descricao." custa R$ ".number_format($p1->preco, 2)." reais. [ ".date('d/m/Y H:i:s')." ] <br>";	
	$p1->alterarPreco(25);
	echo "O produto ".$p1->descricao." custa R$ ".number_format($p1->preco, 2)." reais. [ ".date('d/m/Y H:i:s')." ] <br>";	

?>