<?php  

	include_once 'classes/Cesta.php';
	include_once 'classes/Produto.php';

	# Criando uma cesta
	$cesta =  new Cesta();

	$p3 = new Produto("Soundbar", 1, 1999.99 );
	# Agregação dos Produtos
	$cesta->addItem($p1 = new Produto("Samsung s22", 1, 2999.99 ) );
	$cesta->addItem($p2 = new Produto("TV 55'", 1, 2999.99 ) );
	$cesta->addItem($p3);

	foreach($cesta->getItens() as $c){
		echo "Item: ".$c->getDescricao()."<br>";
	}


?>