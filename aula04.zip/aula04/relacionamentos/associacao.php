<?php  

	include_once 'classes/Fornecedor.php';
	include_once 'classes/Produto.php';


	$p1 = new Produto("Arroz Integral", 100, 12.99);
	$magalu = new Fornecedor("Magalu", "Magazine Luiza S.A", "02156154221000130");

	# Criando uma associação
	$p1->setFornecedor($magalu);

	echo "O Produto ".$p1->getDescricao()." custa ".$p1->getPreco()."<br>";
	echo "O Fornecedor é ".$p1->getFornecedor()->getNome()."<br>";


?>