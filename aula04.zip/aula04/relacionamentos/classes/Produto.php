<?php  
	
	class Produto {

		private $descricao;
		private $estoque;
		private $preco;
		private $fornecedor;

		/* ---- composição --- -*/
		private $caracteristicas;

		public function __construct($descricao, $estoque, $preco){
			$this->descricao = $descricao;
			$this->estoque = $estoque;
			$this->preco = $preco;
		}


		# Metódos acessores
		public function getDescricao(){
			return $this->descricao;
		}

		public function getPreco(){
			return $this->preco;
		}

		public function setFornecedor($fornecedor){
			$this->fornecedor = $fornecedor;
		}

		public function getFornecedor(){
			return $this->fornecedor;
		}

		/* ------- composição ----- */ 
		public function addCaracteristica($nome, $valor){
			$this->caracteristicas[] = new Caracteristica($nome, $valor);
		}	

		public function getCaracteristicas(){
			return $this->caracteristicas;
		}
	}
?>