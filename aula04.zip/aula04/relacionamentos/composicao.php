<?php  

	include_once 'classes/Caracteristica.php';
	include_once 'classes/Produto.php';

	$p1 = new Produto("Samsung S22", 1, 2999.99);

	$p1->addCaracteristica('Memoria RAM', '8 GB');	
	$p1->addCaracteristica('Memoria ROM', '256 GB');	
	$p1->addCaracteristica('Cor', 'Azul');	
	$p1->addCaracteristica('Versão Android', '12');

	echo "Produto: ".$p1->getDescricao()."<br>";

	foreach($p1->getCaracteristicas() as $c){
		echo "&nbsp;&nbsp;&nbsp; Caracteristica: ".$c->getNome()." ".$c->getValor()."<br>";
	}



?>