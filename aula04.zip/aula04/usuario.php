<?php  
	
	# Acessando a classe de Usuário
	include_once 'Usuario.php';

	# Instanciar um objeto do tipo Usuário
	$douglas = new Usuario();
		$douglas->nome = "Douglas";
		$douglas->email = "douglas@email.com";
		$douglas->cpf = "78945612378";
		$douglas->dtNasc = "01/01/2020";

	$douglas->mostraDados();	


	$gabriel = new Usuario();	
		$gabriel->nome = "Gabriel";
		$gabriel->email = "gabriel@email.com";
		$gabriel->cpf = "78945612389";
		$gabriel->dtNasc = "01/01/2021";

	$gabriel->mostraDados();


?>