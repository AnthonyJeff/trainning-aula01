<?php  


	//$conn = mysqli_connect($servidor, $usuario, $senha, $banco) or die("Erro de conexão!!! Verifique ".mysqli_connect_error());
	$conn = new PDO('mysql:host=localhost;dbname=loja', 'root', '');

	//print_r($conn);
	$produtos = $conn->query("SELECT * FROM produtos");

	//var_dump($produtos);
	
	if($produtos){
		foreach ($produtos as $key => $value) {
			echo "Nome: ".$value['produto_nome']."<br>";
			echo "Codigo: ".$value['produto_codigo']."<br>";
			echo "Estoque: ".$value['produto_estoque']."<br>";
			echo '<hr>';
		}
	}


?>


