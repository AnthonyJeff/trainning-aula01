<?php  

	phpinfo();

?>