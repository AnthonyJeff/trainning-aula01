<?php  

	
	
	
	class ProdutoController {

		private $model;

		# Lista de Produtos
		public function lista(){
			$this->model = new ProdutoModel();
			$lista = $this->model->mostrarTodos();			
			include dirname(__DIR__).'/Views/produtos/lista.php';
		}

		public function incluir(){
			include dirname(__DIR__).'/Views/produtos/incluir.php';
		}

		# Carrega a View de ALteração
		public function alterar($id){
			$this->model = new ProdutoModel();
			$produto =$this->model->mostrarUm($id)[0];
			include dirname(__DIR__).'/Views/produtos/alterar.php';
		}

		public function salvar($array){
			$this->model = new ProdutoModel();
			if(isset($array['id_produto'])){
				$lista = $this->model->atualizar($array, $array['id_produto']);
			}else{
				$lista = $this->model->salvar($array);
			}
			//include dirname(__DIR__).'/Views/produtos/lista.php';
			$this->lista();
		}

		public function excluir($id){
			$this->model = new ProdutoModel();
			$lista = $this->model->excluir($id);
			//$this->lista();
		}


		public function relatorio(){

			// Require composer autoload
			require_once dirname(__DIR__) . '/vendor/autoload.php';

			/*
			// Create an instance of the class:
			$mpdf = new \Mpdf\Mpdf();

			$this->model = new ProdutoModel();
			$lista = $this->model->mostrarTodos();

			$html = '
				<h1> Lista de Produtos em PDF </h1>

				<table border="2" style="border: 3px;">
					<thead>
						<th> Nome </th>
						<th> Codigo </th>
						<th> Estoque </th>
						
					</thead>	

					<tbody>';
					foreach($lista as $p):
						$html .= '<tr>
							<td>'.$p['produto_nome'].'</td>
							<td>'.$p['produto_codigo'].'</td>
							<td>'.$p['produto_estoque'].'</td>							
						</tr>';
					endforeach;

					$html .= '</tbody>
				</table>';

				
			// Write some HTML code:
			$mpdf->WriteHTML($html);

			// Output a PDF file directly to the browser
			$mpdf->Output();
			
			//echo $html;
			*/

					

			//use PhpOffice\PhpSpreadsheet\Spreadsheet;
			//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

			$spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();
			$sheet = $spreadsheet->getActiveSheet();
			$sheet->setCellValue('A1', 'Hello World !');

			$writer = new Xlsx($spreadsheet);
			$writer->save('hello world.xlsx');

			
		}
		


	}


	/*$p1 = new ProdutoController();
	$p1->lista();*/




?>