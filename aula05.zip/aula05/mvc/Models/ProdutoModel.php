<?php  


	class ProdutoModel extends Manager{

		# Select 
		public function mostrarTodos(){
			return $this->select_common("produtos", null, null, null);
		}

		public function mostrarUm($id){
			return $this->select_common("produtos", null, ['id_produto'=>$id ], null);
		}

		public function salvar($array){
			return $this->insert_common("produtos", $array, null);
		}

		public function excluir($id){
			return $this->delete_common("produtos", ['id_produto'=>$id], null);
		}

		public function atualizar($array, $id){
			return $this->update_common("produtos", $array,['id_produto'=> $id ],null);
		}
	}



?>