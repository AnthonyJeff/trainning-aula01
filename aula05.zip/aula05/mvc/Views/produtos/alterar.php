<form action="routes.php?produto&route=salvar" method="POST">
	<label> Nome Produto: </label><br>
	<input type="text" name="produto_nome" placeholder="Nome do Produto" value="<?=$produto['produto_nome'];?>"><br><br>

	<label> Produto Codigo: </label><br>
	<input type="text" name="produto_codigo" placeholder="Codigo do Produto" value="<?=$produto['produto_codigo'];?>"><br><br>

	<label> Estoque do Produto: </label><br>
	<input type="text" name="produto_estoque" placeholder="Estoque do Produto" value="<?=$produto['produto_estoque'];?>"><br><br>

	<input type="hidden" name="id_produto" value="<?=$produto['id_produto'];?>">

	<input type="submit">
</form>
