<form action="routes.php?produto&route=salvar" method="POST">
	<label> Nome Produto: </label><br>
	<input type="text" name="produto_nome" placeholder="Nome do Produto"><br><br>

	<label> Produto Codigo: </label><br>
	<input type="text" name="produto_codigo" placeholder="Codigo do Produto"><br><br>

	<label> Estoque do Produto: </label><br>
	<input type="text" name="produto_estoque" placeholder="Estoque do Produto"><br><br>

	<input type="submit">
</form>
