<h1> Cheguei na Lista </h1>

<table border=2>
	<thead>
		<th> Nome </th>
		<th> Codigo </th>
		<th> Estoque </th>
		<th colspan="2"> Ações </th>
	</thead>	

	<tbody>
		<?php foreach($lista as $p):?>
			<tr>
				<td><?=$p['produto_nome'];?></td>
				<td><?=$p['produto_codigo'];?></td>
				<td><?=$p['produto_estoque'];?></td>
				<td><a href="routes.php?produto&route=excluir&id=<?=$p['id_produto'];?>"> Excluir </a></td>
				<td><a href="routes.php?produto&route=alterar&id=<?=$p['id_produto'];?>"> Editar </a></td>
			</tr>
		<?php endforeach; ?>

	</tbody>

</table>

