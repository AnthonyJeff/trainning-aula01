<?php  

	if(isset($_GET['produto'])){

		include_once __DIR__.'/App/Connect.php';
		include_once __DIR__.'/App/Manager.php';
		include_once 'Controllers/ProdutoController.php';
		include_once __DIR__.'/Models/ProdutoModel.php';

		if(isset($_GET['route'])){

			switch ($_GET['route']){

				case 'listar':
					$p1 = new ProdutoController();
					$p1->lista();
				break;

				case 'incluir':
					$p1 = new ProdutoController();
					$p1->incluir();
				break;

				case 'salvar':
					//var_dump($_POST);
					$p1 = new ProdutoController();
					$p1->salvar($_POST);
				break;

				case 'excluir':
					//var_dump($_GET);
					$p1 = new ProdutoController();
					$p1->excluir($_GET['id']);
					header("location: routes.php?produto&route=listar");
				break;

				case 'alterar':
					$p1 = new ProdutoController();
					$p1->alterar($_GET['id']);
				break;

				case 'relatorio':
					$p1 = new ProdutoController();
					$p1->relatorio();
				break;
			}			

		}else{
			$p1 = new ProdutoController();
			$p1->lista();	
		}
		
		

	}




?>