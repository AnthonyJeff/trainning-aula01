<?php  

	class Funcionario extends Pessoa{

		private $cargo;
		private $salario;

		public function contrata($c, $s){
			if(is_numeric($s) AND $s > 0){
				$this->cargo = $c;
				$this->salario = $s;
			}
		}

		public function getInfo(){
			return "Nome: ".$this->nome."; Salário: ".$this->salario;
		}


	}


?>