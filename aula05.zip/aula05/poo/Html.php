<?php  

	class Html{


		public static function title($title){
			return '<title>'.$title.'</title>'."\n";
		}


		public static function abreTag($tag){
			return "<$tag>\n";
		}

		public static function fechaTag($tag){
			return "</$tag>\n";
		}

		public static function texto($texto){
			return $texto;
		}

	}


?>