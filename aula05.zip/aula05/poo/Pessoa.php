<?php  

	class Pessoa{

		protected $nome;
		private $endereco;
		private $dtNasc;

		public function __construct($nome, $endereco){
			$this->nome = $nome;
			$this->endereco = $endereco;
		}

		public function setDtNasc($dtNasc){
			$partes = explode("-", $dtNasc);

			if(count($partes) == 3){
				if(checkdate($partes[1], $partes[2], $partes[0])){
					$this->dtNasc = $dtNasc;
					return true;
				}

				return false;
			}

			return false;
		}

		public function getNome(){
			return $this->nome;
		}
	}



?>