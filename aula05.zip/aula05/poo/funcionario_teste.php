<?php  

	include_once 'Pessoa.php';
	include_once 'Funcionario.php';

	$f1 = new Funcionario("Anthony", "Rua Bem Alí, 222");
	$f1->contrata("Instrutor PHP", 1500);

	echo $f1->getInfo();

?>