<?php  

	/*
	# Incluindo a classe
	include_once 'Pessoa.php';

	# Instanciando o objeto
	$p1 = new Pessoa("Anthony", "Rua Bem Alí, 222");
	//$p1->dtNasc = '2015-05-01';

	if($p1->setDtNasc('01 de Maio de 2015')){
		echo "Atribiu 01 de Maio de 2015 para o atributo.<br>";
	}else{
		echo "Não atribiu 01 de Maio de 2015 para o atributo. Formato incorreto.<br>";
	}

	if($p1->setDtNasc('2015-05-01')){
		echo "Atribiu 01 de Maio de 2015 para o atributo.<br>";
	}else{
		echo "Não atribiu 01 de Maio de 2015 para o atributo. Formato incorreto.<br>";
	}

	*/

	include_once 'Software.php';


	new Software("Sublime");
	new Software("VsCode");
	new Software("CodeIgniter");
	new Software("Gimp");
	new Software("Inkscape");
	new Software("Dreamwaver");

	echo "Quantos Softwares eu tenho? ". Software::$contador;



?>