<?php  
	
	include_once 'Html.php';

	echo Html::abreTag('html');
	echo Html::abreTag('head');
		echo Html::title('Teste Metodo Statico');
	echo Html::fechaTag('head');
	echo Html::abreTag('body');
		echo Html::abreTag('h1');
			echo Html::texto("PHP ORIENTADO A OBJETOS");
		echo Html::fechaTag('h1');
	echo Html::fechaTag('body');
	echo Html::fechaTag('html');



?>